// ============================================
// LUMIÈRE - Premium Cosmetics Store
// Product Data & Functionality
// ============================================

// Product Database
const products = [
    {
        id: 1,
        name: 'Luxe Lip Tint',
        category: 'makeup',
        price: '285,000₫',
        priceNum: 285000,
        image: 'https://images.unsplash.com/photo-1586496892212-a7e90b8e5955?w=500&h=500&fit=crop'
    },
    {
        id: 2,
        name: 'Radiant Foundation',
        category: 'makeup',
        price: '420,000₫',
        priceNum: 420000,
        image: 'https://images.unsplash.com/photo-1571875257842-36bf748f7629?w=500&h=500&fit=crop'
    },
    {
        id: 3,
        name: 'Rose Blush Harmony',
        category: 'makeup',
        price: '320,000₫',
        priceNum: 320000,
        image: 'https://images.unsplash.com/photo-1599599810694-a5d5f1e98f63?w=500&h=500&fit=crop'
    },
    {
        id: 4,
        name: 'Silk Eye Palette',
        category: 'makeup',
        price: '380,000₫',
        priceNum: 380000,
        image: 'https://images.unsplash.com/photo-1595614635233-90e6b308ca10?w=500&h=500&fit=crop'
    },
    {
        id: 5,
        name: 'Premium Brush Set',
        category: 'accessories',
        price: '550,000₫',
        priceNum: 550000,
        image: 'https://images.unsplash.com/photo-1571875257842-36bf748f7629?w=500&h=500&fit=crop'
    },
    {
        id: 6,
        name: 'Crystal Beauty Mirror',
        category: 'accessories',
        price: '220,000₫',
        priceNum: 220000,
        image: 'https://images.unsplash.com/photo-1586496892212-a7e90b8e5955?w=500&h=500&fit=crop'
    },
    {
        id: 7,
        name: 'Perfume Decant Collection',
        category: 'decant',
        price: '145,000₫',
        priceNum: 145000,
        image: 'https://images.unsplash.com/photo-1599599810694-a5d5f1e98f63?w=500&h=500&fit=crop'
    },
    {
        id: 8,
        name: 'Mini Skincare Set',
        category: 'minisize',
        price: '195,000₫',
        priceNum: 195000,
        image: 'https://images.unsplash.com/photo-1595614635233-90e6b308ca10?w=500&h=500&fit=crop'
    }
];

// Shopping Cart State
let cart = [];

// DOM Elements
const productsGrid = document.getElementById('productsGrid');
const cartBtn = document.getElementById('cartBtn');
const cartClose = document.getElementById('cartClose');
const cartModal = document.getElementById('cartModal');
const cartOverlay = document.getElementById('cartOverlay');
const cartCount = document.getElementById('cartCount');
const cartBody = document.getElementById('cartBody');
const cartTotal = document.getElementById('cartTotal');
const navLinks = document.querySelectorAll('.nav-link');
const heroButton = document.querySelector('.hero-button');
const newsletterForm = document.getElementById('newsletterForm');

// ============================================
// INITIALIZATION
// ============================================

document.addEventListener('DOMContentLoaded', () => {
    renderProducts(products);
    setupEventListeners();
    loadCartFromStorage();
});

// ============================================
// EVENT LISTENERS
// ============================================

function setupEventListeners() {
    // Cart button
    cartBtn.addEventListener('click', openCart);
    cartClose.addEventListener('click', closeCart);
    cartOverlay.addEventListener('click', closeCart);

    // Navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            handleNavigation(link);
        });
    });

    // Hero button
    heroButton.addEventListener('click', () => {
        const productsSection = document.querySelector('.featured-section');
        productsSection.scrollIntoView({ behavior: 'smooth' });
    });

    // Newsletter form
    newsletterForm.addEventListener('submit', handleNewsletterSubmit);

    // Logo click
    document.querySelector('.logo').addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

// ============================================
// PRODUCT RENDERING
// ============================================

function renderProducts(productsToRender) {
    productsGrid.innerHTML = '';
    
    if (productsToRender.length === 0) {
        productsGrid.innerHTML = '<p style="text-align: center; grid-column: 1 / -1;">No products found</p>';
        return;
    }

    productsToRender.forEach((product, index) => {
        const productCard = createProductCard(product);
        productsGrid.appendChild(productCard);
    });
}

function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
        <div class="product-image-wrapper">
            <img src="${product.image}" alt="${product.name}" class="product-image" loading="lazy">
        </div>
        <div class="product-info">
            <h3 class="product-name">${product.name}</h3>
            <p class="product-price">${product.price}</p>
            <button class="add-to-cart-btn" onclick="addToCart(${product.id})">
                Add to Cart
            </button>
        </div>
    `;
    return card;
}

// ============================================
// CART FUNCTIONALITY
// ============================================

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    
    if (product) {
        cart.push(product);
        updateCart();
        saveCartToStorage();
        showAddedNotification(product.name);
    }
}

function removeFromCart(index) {
    cart.splice(index, 1);
    updateCart();
    saveCartToStorage();
}

function updateCart() {
    updateCartCount();
    renderCartItems();
    updateCartTotal();
}

function updateCartCount() {
    cartCount.textContent = cart.length;
    cartCount.style.animation = 'none';
    setTimeout(() => {
        cartCount.style.animation = 'pulse 0.5s ease-out';
    }, 10);
}

function renderCartItems() {
    if (cart.length === 0) {
        cartBody.innerHTML = '<p class="empty-cart-message">Your cart is empty</p>';
        return;
    }

    cartBody.innerHTML = cart.map((item, index) => `
        <div class="cart-item">
            <div class="cart-item-image">
                <img src="${item.image}" alt="${item.name}">
            </div>
            <div class="cart-item-details">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-price">${item.price}</div>
                <button class="cart-item-remove" onclick="removeFromCart(${index})">Remove</button>
            </div>
        </div>
    `).join('');
}

function updateCartTotal() {
    const total = cart.reduce((sum, item) => sum + item.priceNum, 0);
    const formattedTotal = total.toLocaleString('vi-VN') + '₫';
    cartTotal.textContent = formattedTotal;
}

// ============================================
// CART MODAL
// ============================================

function openCart() {
    cartModal.classList.add('active');
    cartOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeCart() {
    cartModal.classList.remove('active');
    cartOverlay.classList.remove('active');
    document.body.style.overflow = 'auto';
}

// ============================================
// NAVIGATION & FILTERING
// ============================================

function handleNavigation(link) {
    // Remove active class from all links
    navLinks.forEach(l => l.classList.remove('active'));
    
    // Add active class to clicked link
    link.classList.add('active');
    
    // Get category from data attribute
    const category = link.getAttribute('data-category');
    
    // Filter products
    filterByCategory(category);
}

function filterByCategory(category) {
    let filtered = products;
    
    if (category !== 'all') {
        filtered = products.filter(p => p.category === category);
    }
    
    renderProducts(filtered);
}

// ============================================
// NOTIFICATIONS
// ============================================

function showAddedNotification(productName) {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #e8b4c8, #c96fa3);
        color: white;
        padding: 16px 24px;
        border-radius: 6px;
        font-family: 'Montserrat', sans-serif;
        font-size: 13px;
        font-weight: 600;
        letter-spacing: 0.5px;
        animation: slideIn 0.4s ease-out;
        z-index: 9999;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
    `;
    notification.textContent = `✓ ${productName} added to cart`;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.4s ease-out forwards';
        setTimeout(() => {
            notification.remove();
        }, 400);
    }, 2500);
}

// ============================================
// NEWSLETTER
// ============================================

function handleNewsletterSubmit(e) {
    e.preventDefault();
    const email = e.target.querySelector('input[type="email"]').value;
    
    if (email) {
        showNewsletterConfirmation();
        e.target.reset();
    }
}

function showNewsletterConfirmation() {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #90EE90, #66BB6A);
        color: white;
        padding: 16px 24px;
        border-radius: 6px;
        font-family: 'Montserrat', sans-serif;
        font-size: 13px;
        font-weight: 600;
        animation: slideIn 0.4s ease-out;
        z-index: 9999;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
    `;
    notification.textContent = '✓ Thank you for subscribing!';
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.4s ease-out forwards';
        setTimeout(() => {
            notification.remove();
        }, 400);
    }, 3000);
}

// ============================================
// LOCAL STORAGE
// ============================================

function saveCartToStorage() {
    localStorage.setItem('lumiere_cart', JSON.stringify(cart));
}

function loadCartFromStorage() {
    const stored = localStorage.getItem('lumiere_cart');
    if (stored) {
        try {
            cart = JSON.parse(stored);
            updateCart();
        } catch (e) {
            console.error('Error loading cart:', e);
        }
    }
}

// ============================================
// ANIMATIONS (CSS)
// ============================================

const styles = document.createElement('style');
styles.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }

    @keyframes pulse {
        0%, 100% {
            transform: scale(1);
        }
        50% {
            transform: scale(1.25);
        }
    }

    @media (max-width: 480px) {
        @keyframes slideIn {
            from {
                transform: translateY(100px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @keyframes slideOut {
            from {
                transform: translateY(0);
                opacity: 1;
            }
            to {
                transform: translateY(100px);
                opacity: 0;
            }
        }
    }
`;
document.head.appendChild(styles);
